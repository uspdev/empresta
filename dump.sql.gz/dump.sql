-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: empresta
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria_setor`
--

DROP TABLE IF EXISTS `categoria_setor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_setor` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` bigint(20) unsigned NOT NULL,
  `setor_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categoria_setor_categoria_id_foreign` (`categoria_id`),
  KEY `categoria_setor_setor_id_foreign` (`setor_id`),
  CONSTRAINT `categoria_setor_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categoria_setor_setor_id_foreign` FOREIGN KEY (`setor_id`) REFERENCES `setores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_setor`
--

LOCK TABLES `categoria_setor` WRITE;
/*!40000 ALTER TABLE `categoria_setor` DISABLE KEYS */;
INSERT INTO `categoria_setor` VALUES (6,33,3,NULL,NULL);
/*!40000 ALTER TABLE `categoria_setor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria_vinculo`
--

DROP TABLE IF EXISTS `categoria_vinculo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_vinculo` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` bigint(20) unsigned NOT NULL,
  `vinculo_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categoria_vinculo_categoria_id_foreign` (`categoria_id`),
  KEY `categoria_vinculo_vinculo_id_foreign` (`vinculo_id`),
  CONSTRAINT `categoria_vinculo_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`),
  CONSTRAINT `categoria_vinculo_vinculo_id_foreign` FOREIGN KEY (`vinculo_id`) REFERENCES `vinculos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_vinculo`
--

LOCK TABLES `categoria_vinculo` WRITE;
/*!40000 ALTER TABLE `categoria_vinculo` DISABLE KEYS */;
INSERT INTO `categoria_vinculo` VALUES (3,33,3,NULL,NULL);
/*!40000 ALTER TABLE `categoria_vinculo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'2023-08-28 16:12:12','2023-08-28 16:12:12','Chave'),(2,'2023-08-29 10:38:48','2023-08-29 10:38:48','Kit para aula'),(3,'2023-08-31 15:12:37','2023-08-31 15:12:37','Categoria Teste'),(30,'2024-03-08 13:30:42','2024-03-08 13:49:56','Teste Depois de Editar'),(31,'2024-03-08 13:51:52','2024-03-08 13:52:40','Testando'),(32,'2024-03-12 13:06:57','2024-03-12 13:06:57','Uma Categoria Qualquer'),(33,'2024-03-12 14:16:12','2024-03-12 14:16:12','Graduação');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emprestimos`
--

DROP TABLE IF EXISTS `emprestimos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emprestimos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `data_emprestimo` datetime NOT NULL,
  `data_devolucao` datetime DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitante_id` bigint(20) unsigned DEFAULT NULL,
  `material_id` bigint(20) unsigned DEFAULT NULL,
  `created_by_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emprestimos_visitante_id_foreign` (`visitante_id`),
  KEY `emprestimos_material_id_foreign` (`material_id`),
  KEY `emprestimos_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `emprestimos_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `emprestimos_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`),
  CONSTRAINT `emprestimos_visitante_id_foreign` FOREIGN KEY (`visitante_id`) REFERENCES `visitantes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emprestimos`
--

LOCK TABLES `emprestimos` WRITE;
/*!40000 ALTER TABLE `emprestimos` DISABLE KEYS */;
INSERT INTO `emprestimos` VALUES (1,'2023-08-29 11:05:46','2023-09-04 14:32:48','2023-08-29 11:05:46','2023-09-04 14:32:48','11848538',NULL,17,1),(2,'2023-08-29 14:33:26','2023-08-29 14:35:14','2023-08-29 14:33:26','2023-08-29 14:35:14','11848538',NULL,18,1),(3,'2023-08-29 15:43:41','2024-03-05 15:08:57','2023-08-29 15:43:41','2024-03-05 15:08:57','11848538',NULL,18,1),(4,'2023-08-31 15:37:48','2023-09-04 14:33:25','2023-08-31 15:37:48','2023-09-04 14:33:25','0',1,1,1),(5,'2023-09-04 14:33:41','2023-09-04 14:37:15','2023-09-04 14:33:41','2023-09-04 14:37:15','11848538',NULL,1,1),(6,'2023-09-04 14:37:30','2023-09-04 15:56:31','2023-09-04 14:37:30','2023-09-04 15:56:31','11848538',NULL,1,1),(7,'2023-09-04 15:56:38','2023-09-05 13:43:08','2023-09-04 15:56:38','2023-09-05 13:43:08','11848538',NULL,1,1),(8,'2023-09-04 15:57:49','2023-09-04 15:58:24','2023-09-04 15:57:49','2023-09-04 15:58:24','11848538',NULL,2,1),(9,'2023-09-04 15:59:18','2023-09-04 16:00:51','2023-09-04 15:59:18','2023-09-04 16:00:51','11848538',NULL,3,1),(10,'2023-09-04 16:00:57','2023-09-04 16:01:00','2023-09-04 16:00:57','2023-09-04 16:01:00','11848538',NULL,3,1),(11,'2023-09-04 16:01:24','2023-09-05 13:43:10','2023-09-04 16:01:24','2023-09-05 13:43:10','11848538',NULL,24,1),(12,'2023-09-04 16:11:15','2023-09-05 13:43:12','2023-09-04 16:11:15','2023-09-05 13:43:12','11848538',NULL,21,1),(13,'2023-09-05 13:43:21','2024-03-05 15:08:54','2023-09-05 13:43:21','2024-03-05 15:08:54','11848538',NULL,21,1),(14,'2023-09-05 13:43:36','2023-09-05 13:43:36','2023-09-05 13:43:36',NULL,'0',1,24,1),(15,'2023-09-05 16:50:29','2023-09-05 16:50:29','2023-09-05 16:50:29',NULL,'4904005',NULL,3,1),(16,'2023-09-05 16:54:55','2023-09-05 16:54:55','2023-09-05 16:54:55',NULL,'13836789',NULL,2,1),(17,'2024-03-05 15:09:19','2024-03-05 15:09:19','2024-03-05 15:09:19',NULL,'11848538',NULL,10,1),(18,'2024-03-05 15:09:43','2024-03-05 15:09:43','2024-03-05 15:09:43',NULL,'11848538',NULL,21,1),(19,'2024-03-12 14:16:48','2024-03-12 14:16:48','2024-03-12 14:16:48',NULL,'12291825',NULL,16,1),(20,'2024-03-12 14:47:28','2024-03-12 14:48:31','2024-03-12 14:47:28','2024-03-12 14:48:31','11848538',NULL,26,1),(21,'2024-03-12 14:54:37','2024-03-12 14:54:48','2024-03-12 14:54:37','2024-03-12 14:54:48','11778537',NULL,26,1);
/*!40000 ALTER TABLE `emprestimos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ativo` int(11) NOT NULL,
  `codigo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria_id` bigint(20) unsigned DEFAULT NULL,
  `created_by_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `materials_categoria_id_foreign` (`categoria_id`),
  KEY `materials_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `materials_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`),
  CONSTRAINT `materials_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES (1,'2023-08-28 16:12:37','2023-09-04 14:36:56',1,'0001','A3 – Laboratório Pós-Graduação',1,1),(2,'2023-08-28 16:12:55','2023-09-04 15:58:07',1,'B02','B2 – Laboratório Fotografia',1,1),(3,'2023-08-28 16:13:03','2023-09-04 16:01:10',1,'B03','B3 – Licenciatura',1,1),(4,'2023-08-28 16:13:13','2023-08-28 16:13:13',1,'4','B4/B5 – Gravura / Serigrafia',1,1),(5,'2023-08-28 16:13:23','2023-08-28 16:13:23',1,'5','B6 – Serralheria',1,1),(6,'2023-08-28 16:13:33','2023-08-28 16:13:33',1,'6','B7/B8 – Marcenaria',1,1),(7,'2023-08-28 16:13:41','2023-08-28 16:13:41',1,'7','B9 – Ateliê de Cerâmica',1,1),(8,'2023-08-28 16:13:50','2023-08-28 16:13:50',1,'8','C1 – Grupo de Estudos',1,1),(9,'2023-08-28 16:14:09','2023-08-28 16:14:09',1,'9','C2 – Estúdio Foto/Vídeo',1,1),(10,'2023-08-28 16:14:19','2023-08-28 16:14:19',1,'10','C6 – Laboratório Multimídia',1,1),(11,'2023-08-28 16:14:28','2023-08-28 16:14:28',1,'11','C7 – Sala de Aula',1,1),(12,'2023-08-28 16:14:38','2023-08-28 16:14:38',1,'12','C8 – Sala de Aula',1,1),(13,'2023-08-28 16:14:46','2023-08-28 16:14:46',1,'13','C9 – Ateliê de Pintura',1,1),(14,'2023-08-28 16:14:55','2023-08-28 16:14:55',1,'14','C10 – Puxadinho',1,1),(15,'2023-08-29 10:39:02','2023-08-29 10:39:02',1,'9287','Projetor',2,1),(16,'2023-08-29 10:39:16','2023-08-29 10:39:16',1,'213','Webcam',2,1),(17,'2023-08-29 10:39:22','2023-08-29 10:39:22',1,'9278','Giz',2,1),(18,'2023-08-29 10:39:34','2023-08-29 10:39:34',1,'91287','Ponteiro',2,1),(19,'2023-08-29 10:40:00','2023-08-29 10:40:00',1,'67','Quadro',2,1),(20,'2023-08-31 15:13:00','2023-08-31 15:13:00',1,'898','Material para Teste',3,1),(21,'2023-09-04 14:27:39','2023-09-04 16:13:08',1,'001','Chave de Teste Novamente',2,1),(22,'2023-09-04 14:29:46','2023-09-04 14:29:46',0,'AC3','Chave teste 2',1,1),(23,'2023-09-04 15:56:23','2023-09-04 15:56:23',1,'00000001','Teste2',1,1),(24,'2023-09-04 16:00:30','2023-09-04 16:00:30',1,'0000000000003','Teste 4',2,1),(25,'2023-09-05 13:48:44','2023-09-05 13:48:44',0,'1231','adfasf',1,1),(26,'2024-03-12 14:17:32','2024-03-12 14:17:32',1,'CGR','Teste',33,1);
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_03_19_190119_create_categorias_table',1),(5,'2021_03_19_190127_create_materials_table',1),(6,'2021_03_19_190136_create_visitantes_table',1),(7,'2021_03_19_190151_create_emprestimos_table',1),(8,'2021_05_05_210543_create_jobs_table',1),(9,'2021_09_22_131642_create_permission_tables',1),(10,'2022_03_08_170616_add_column_codpes_to_users',1),(11,'2023_09_04_135315_alter_materials_table',2),(16,'2024_03_06_143010_create_vinculos_table',3),(23,'2024_03_06_143722_create_setores_table',4),(24,'2024_03_06_144642_create_categoria_setor_table',4),(25,'2024_03_06_144650_create_categoria_vinculo_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (4,'App\\Models\\User',1),(11,'App\\Models\\User',1),(20,'App\\Models\\User',1),(26,'App\\Models\\User',1),(27,'App\\Models\\User',1),(8,'App\\Models\\User',11),(17,'App\\Models\\User',11),(8,'App\\Models\\User',15),(10,'App\\Models\\User',15),(31,'App\\Models\\User',15),(8,'App\\Models\\User',16),(14,'App\\Models\\User',16),(8,'App\\Models\\User',17),(15,'App\\Models\\User',17),(8,'App\\Models\\User',18),(9,'App\\Models\\User',18),(32,'App\\Models\\User',18),(8,'App\\Models\\User',22),(8,'App\\Models\\User',23),(16,'App\\Models\\User',23),(8,'App\\Models\\User',36),(12,'App\\Models\\User',36),(34,'App\\Models\\User',36),(8,'App\\Models\\User',39),(12,'App\\Models\\User',39),(35,'App\\Models\\User',39),(8,'App\\Models\\User',40),(12,'App\\Models\\User',40),(36,'App\\Models\\User',40),(8,'App\\Models\\User',42),(13,'App\\Models\\User',42),(37,'App\\Models\\User',42),(8,'App\\Models\\User',44),(12,'App\\Models\\User',44),(36,'App\\Models\\User',44),(8,'App\\Models\\User',45),(16,'App\\Models\\User',45),(8,'App\\Models\\User',46),(11,'App\\Models\\User',46),(38,'App\\Models\\User',46),(8,'App\\Models\\User',47),(13,'App\\Models\\User',47),(8,'App\\Models\\User',48),(13,'App\\Models\\User',48),(39,'App\\Models\\User',48);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'admin','web','2023-08-28 16:11:59','2023-08-28 16:11:59'),(2,'gerente','web','2023-08-28 16:11:59','2023-08-28 16:11:59'),(3,'user','web','2023-08-28 16:11:59','2023-08-28 16:11:59'),(4,'admin','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(5,'boss','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(6,'manager','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(7,'poweruser','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(8,'user','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(9,'Servidor','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(10,'Docente','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(11,'Estagiario','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(12,'Alunogr','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(13,'Alunopos','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(14,'Alunoceu','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(15,'Alunoead','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(16,'Alunopd','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(17,'Servidorusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(18,'Docenteusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(19,'Estagiariousp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(20,'Alunogrusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(21,'Alunoposusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(22,'Alunoceuusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(23,'Alunoeadusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(24,'Alunopdusp','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(25,'Outros','senhaunica','2023-08-31 15:08:22','2023-08-31 15:08:22'),(26,'balcao','web','2024-02-07 14:45:20','2024-02-07 14:45:20'),(27,'Estagiario.scdesauto','senhaunica','2024-03-05 14:35:56','2024-03-05 14:35:56'),(28,'Servidor.scdesauto','senhaunica','2024-03-05 14:36:10','2024-03-05 14:36:10'),(29,'Servidor.screlins','senhaunica','2024-03-08 15:37:17','2024-03-08 15:37:17'),(30,'Servidor.atcri','senhaunica','2024-03-11 08:51:35','2024-03-11 08:51:35'),(31,'Docente.cbd','senhaunica','2024-03-11 08:52:01','2024-03-11 08:52:01'),(32,'Servidor.cca','senhaunica','2024-03-11 09:14:25','2024-03-11 09:14:25'),(33,'Servidor.cje','senhaunica','2024-03-11 09:20:06','2024-03-11 09:20:06'),(34,'Alunogr.27011','senhaunica','2024-03-12 14:20:13','2024-03-12 14:20:13'),(35,'Alunogr.27421','senhaunica','2024-03-12 14:56:13','2024-03-12 14:56:13'),(36,'Alunogr.27120','senhaunica','2024-03-12 15:03:13','2024-03-12 15:03:13'),(37,'Alunopos.27164','senhaunica','2024-03-12 15:11:45','2024-03-12 15:11:45'),(38,'Estagiario.svposgr','senhaunica','2024-03-12 15:13:32','2024-03-12 15:13:32'),(39,'Alunopos.27161','senhaunica','2024-03-12 15:14:22','2024-03-12 15:14:22');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setores`
--

DROP TABLE IF EXISTS `setores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setores`
--

LOCK TABLES `setores` WRITE;
/*!40000 ALTER TABLE `setores` DISABLE KEYS */;
INSERT INTO `setores` VALUES (1,'crp','2024-03-12 14:41:56','2024-03-12 14:41:56'),(2,'scdesauto','2024-03-12 14:41:56','2024-03-12 14:41:56'),(3,'cmu','2024-03-12 14:46:51','2024-03-12 14:46:51');
/*!40000 ALTER TABLE `setores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `codpes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Kawan Santana','kawan',NULL,'kawan.santana@usp.br',NULL,'$2y$10$P4yeapoYYPjgGYiTh/2OAuY/ty0JPT7Yw3Do1CGTyq56MD0QhYKom',NULL,'zhi9UUDyFdv1yWCxDI9FMub9acH7qO5uMYAudFhrpza7G6Gt6xYoi8Wi7Q9M','2023-08-28 16:11:59','2023-09-05 14:34:05','11848538'),(2,'Joao da Silva','joao',NULL,NULL,NULL,'$2y$10$ioUOPvlWL6yeS8/oLC8DIuy794umo4NSN7v/FJ3RoCkswbWIWl.hm','Balcao','hBp18rnf56Bu3uoBf1Lrnoa3iWHJencBbNoN4AYOBPgOpFrmn8ovKNOUHdAO','2023-08-30 16:47:20','2023-08-30 16:47:20',NULL),(3,'Maria da Conceição','maria',NULL,NULL,NULL,'$2y$10$pDttfTWHtLhpL7maKDqjpui1KFyx2hNDx1ezEo81/lDGooKGPr0te','Balcao','ZK3QwUFCGUhh8G5NNItjSpkPnuqttdtnzJx3I8cR5nx03llth8ZOuNSmriRI','2023-08-31 15:14:15','2023-09-05 14:34:36',NULL),(6,'Usuario Balcao','user',NULL,NULL,NULL,'$2y$10$M6aKG/br/Ghc1gHTyjUqX.3tuMsvpUwIanYMMUXcQ1JKdD1mJySrO','Balcao','EdWzffZyGSMKVcyWbtLvLBYiP7fdWzoCOYFCVkNy8NbGoI69NCXHQLYbBZni','2024-02-06 10:26:21','2024-02-06 10:26:21',NULL),(11,'Alessandro Costa de Oliveira',NULL,NULL,'alecosta@usp.br',NULL,NULL,NULL,NULL,'2024-03-05 14:33:08','2024-03-05 14:33:08','4984812'),(15,'José Fernando Modesto da Silva',NULL,NULL,'fmodesto@usp.br',NULL,NULL,NULL,NULL,'2024-03-11 08:52:01','2024-03-11 08:52:01','860553'),(16,'Fabiana de Sousa e Silva',NULL,NULL,'silvafa3@hotmail.com',NULL,NULL,NULL,NULL,'2024-03-11 09:13:03','2024-03-11 09:13:03','13078190'),(17,'Tayane Araújo',NULL,NULL,'tayanearauujo@outlook.com',NULL,NULL,NULL,NULL,'2024-03-11 09:14:00','2024-03-11 09:14:00','13097434'),(18,'Marco Antonio Guerra',NULL,NULL,'marco.guerra@terra.com.br',NULL,NULL,NULL,NULL,'2024-03-11 09:14:25','2024-03-11 09:14:25','2087147'),(22,'Aïcha Benzerga',NULL,NULL,'aicha.benzerga@sorbonne-nouvelle.fr',NULL,NULL,NULL,NULL,'2024-03-11 09:36:51','2024-03-11 09:36:51','15014351'),(23,'Alessandra de Castro Barros Marassi',NULL,NULL,'alebarros8@gmail.com',NULL,NULL,NULL,NULL,'2024-03-11 09:42:28','2024-03-11 09:42:28','12291825'),(28,'Manuel Carlos da Conceicao Chaparro',NULL,NULL,'mpchaparro61@gmail.com',NULL,NULL,NULL,NULL,'2024-03-11 10:38:35','2024-03-11 10:38:35','83528'),(31,'Juliette Simone Colette Ratto',NULL,NULL,'juliette.ratto@gmail.com',NULL,NULL,NULL,NULL,'2024-03-11 10:45:42','2024-03-11 10:45:42','13386502'),(36,'Elisa Lago Peres',NULL,NULL,'elisalago@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 14:20:13','2024-03-12 14:20:13','11778537'),(39,'Jonathan da Mota Morais',NULL,NULL,'jonathan.morais@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 14:57:26','2024-03-12 14:57:26','14583438'),(40,'Fernando Americo Cardoso',NULL,NULL,'fernando.cardoso3801@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 15:03:12','2024-03-12 15:03:12','12518987'),(42,'João Alfredo Alineri Ramos',NULL,NULL,'joao.alfredo@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 15:11:45','2024-03-12 15:11:45','13623660'),(44,'Gabriela Rocha Nangino',NULL,NULL,'gabi.nangino@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 15:12:24','2024-03-12 15:12:24','15508907'),(45,'Pedro Razzante Vaccari',NULL,NULL,'pedro.vaccari@theatromunicipal.org.br',NULL,NULL,NULL,NULL,'2024-03-12 15:12:43','2024-03-12 15:12:43','11018622'),(46,'Raquel Bermudes Rico Fernandes',NULL,NULL,'raquelricofernandes@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 15:13:32','2024-03-12 15:13:32','12701918'),(47,'Assahi Pereira Lima',NULL,NULL,'assahi@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 15:14:03','2024-03-12 15:14:03','384531'),(48,'Luísa Helena Leite Nico',NULL,NULL,'luisanico@usp.br',NULL,NULL,NULL,NULL,'2024-03-12 15:14:22','2024-03-12 15:14:22','10304918');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vinculos`
--

DROP TABLE IF EXISTS `vinculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vinculos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vinculos`
--

LOCK TABLES `vinculos` WRITE;
/*!40000 ALTER TABLE `vinculos` DISABLE KEYS */;
INSERT INTO `vinculos` VALUES (1,'Aluno Convênoi Interc Grad','Alunoconvenioint','2024-03-12 12:53:23','2024-03-12 12:53:23'),(2,'Aluno de Cultura e Extensão','Alunoceu','2024-03-12 12:53:23','2024-03-12 12:53:23'),(3,'Aluno de Graduação','Alunogr','2024-03-12 12:53:23','2024-03-12 12:53:23'),(4,'Aluno de Pós-Graduação','Alunopos','2024-03-12 12:53:23','2024-03-12 12:53:23'),(5,'Aluno Escola de Arte Dramática','Alunoead','2024-03-12 12:53:23','2024-03-12 12:53:23'),(6,'Docente','Docente','2024-03-12 12:53:23','2024-03-12 12:53:23'),(7,'Docente Aposentado','Servidor','2024-03-12 12:53:23','2024-03-12 12:53:23'),(8,'Estagiário','Estagiario','2024-03-12 12:53:23','2024-03-12 12:53:23'),(9,'Pós-doutorando','Alunopd','2024-03-12 12:53:23','2024-03-12 12:53:23'),(10,'Servidor','Servidor','2024-03-12 12:53:23','2024-03-12 12:53:23');
/*!40000 ALTER TABLE `vinculos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitantes`
--

DROP TABLE IF EXISTS `visitantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitantes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitantes`
--

LOCK TABLES `visitantes` WRITE;
/*!40000 ALTER TABLE `visitantes` DISABLE KEYS */;
INSERT INTO `visitantes` VALUES (1,'2023-08-31 15:13:43','2023-08-31 15:13:43','Zé Fulano','4056889','zefulano@email.com');
/*!40000 ALTER TABLE `visitantes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-15 17:37:36
